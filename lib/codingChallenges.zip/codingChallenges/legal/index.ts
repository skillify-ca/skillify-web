export function passLsat (percentile) {
    // if percentile is greater than 80 then return "pass"
    // else return "fail"
}