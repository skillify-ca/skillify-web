import { passLsat } from ".";

/*

test("should return pass", () => {
    expect(passLsat(99)).toEqual("Passed");
});

test("should return fail", () => {
expect(passLsat(30)).toEqual("Failed");
});

*/