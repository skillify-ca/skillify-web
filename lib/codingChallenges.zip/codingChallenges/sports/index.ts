
// Variables
export function createPlayer(name:string, team:string) {
    // Create a function that returns a string in the format of [name] has been drafted by [team]
}

// Functions
export function shootingPercentage(shotsMade: number, shotsAttempted: number) {
    
}

// Conditionals
export function isRightHanded(hand: 'left' | 'right' | 'ambidexterous') {
    //Create an if else statement figuring out if player's hand is right-handed or not
}

// Loops
export function shotClock (seconds: number) {
    //Create a loop that counts backwards from seconds to 0 and return 0
}

// Arrays
export function teammateCount(players: string[]){
    //Return number of players in the team
}

export function countWins(games: ('W'|'L')[]) {
    // return the number of wins in the list of games
}

// Objects
// left handedness, passing stats 

// Iterators