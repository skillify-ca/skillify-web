import { countWins, createPlayer, isRightHanded, shootingPercentage, shotClock, teammateCount } from ".";
/*
test("variables test 1", () => {
    expect(createPlayer("Ajevan", "Raptors")).toEqual("Ajevan has been drafted to the Raptors");
});

test("variables test 2", () => {
    expect(createPlayer("Vithushan", "Knicks")).toEqual("Vithushan has been drafted to the Knicks");
});

test("functions test 1", () => {
    expect(shootingPercentage(1, 2)).toEqual(50);
});

test("functions test 1", () => {
    expect(shootingPercentage(10, 10)).toEqual(100);
});

test("conditionals test 1", () => {
    expect(isRightHanded('left')).toEqual(false);
});

test("conditionals test 2", () => {
    expect(isRightHanded('right')).toEqual(true);
});

test("conditionals test 3", () => {
    expect(isRightHanded('ambidexterous')).toEqual(true);
});

test('array test 1',() => {
    expect(teammateCount(["Curry", "Klay", "Draymond", "Wiggins", "Wiseman"])).toEqual(5)
})

test('array test 2',() => {
    expect(countWins(["W", "W", "W", "L", "L"])).toEqual(3)
})

test('array test 3',() => {
    expect(countWins(["L", "L", "L", "L", "L"])).toEqual(0)
})


test ("Loop test", () => {
    expect(shotClock(24)).toEqual(0)
});

*/