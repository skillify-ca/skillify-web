function homeEquity(homeTotalValue, mortgageBalance) {
  /*
   * In this challenge you will be calculating how much home equity you own from the given parameters:
   * the total value of the home, the outstanding mortgage left on your home.
   *
   * Home equity is the value of how much a homeowner actually owns in their home.
   * To calculate home equity use this formula: HomeEquity = HomeTotalValue - MortgageBalance
   * Note: since we are dealing with outputting money, to output to 2 decimal places do .toFixed(2)
   */
  // TODO: write your code here
  return "$0.00";
}

// Use the Run Code extension to run these test cases

//expected output: $400000.00
console.log(homeEquity(900000, 500000));

//expected output: $850000.00
console.log(homeEquity(1000000, 150000));

//expected output: $150000.00
console.log(homeEquity(1000000, 850000));
