/*
 * In this coding challenge you'll make some star patterns using loops!
 * To draw a star use the drawStar() function instead of console.log("*") this will help you avoid format problems
 */

function drawStar() {
  process.stdout.write("*");
}

function starPattern() {
  /* You will print out:

      *
      **
      ***
      ****
      *****

      */
}
function starPattern2() {
  /* You will print out:

      *****
      ****
      ***
      **
      *

      */
}

starPattern();
console.log("");
starPattern2();
