function temperatureConverter(convertFrom, value) {
  /*return statement
   * Notes: Google the formula to convert from:
   * 1) Celsius to Fahrenheit
   * 2) Fahrenheit to Celsius
   */
}

console.log(temperatureConverter("Celsius", 50)); //output: 122
console.log(temperatureConverter("Celsius", 0)); //output: 32
console.log(temperatureConverter("Fahrenheit", 273)); //output: 133.88888888888889
console.log(temperatureConverter("Fahrenheit", -10)); //output: -23.333333333333332
