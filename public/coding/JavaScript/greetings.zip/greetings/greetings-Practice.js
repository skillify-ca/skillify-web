/*
  Here is your first coding challenge. It will combine your knowledge of variables and functions. 
  Your function will take in 3 string parameters and should output a greeting similar to the initial greeting 
  that you sent me when you joined the Slack community for the first time.

  Expected output:
  "Hello my name is ${name}. I have ${phone} and ${computer}."
*/

function greetings(name, phone, laptop) {
  //TODO: your code goes here
  return "something";
}

//Expected Output: "Hello my name is Lavan. I have an Android Phone and a Window computer."
console.log(greetings("Lavan", "an Android Phone", "a Windows computer"));

//Expected Output: "Hello my name is Vithushan. I have a Google Pixel and a Macbook Pro."
console.log(greetings("Vithushan", "a Google Pixel", "a Macbook Pro"));

//Expected Output: "Hello my name is Vithushan. I have an Android Phone and an Apple computer."
console.log(greetings("Ren", "an Android Phone", "an Apple computer"));

//Expected Output: "Hello my name is Kavan. I have an iPhone and a Macbook."
console.log(greetings("Kavan", "an iPhone", "a Macbook"));

/**
 * Use the Run Code extension by typing CMD+SHIFT+P (or CTRL+SHIFT+P) in Visual Studio Code to pull up the Command Pallette
 * Search for Run Code and run the code in this file.
 *
 * What do you need to change so that your code returns the correct expected output?
 *
 * Reach out to people in the community if you're feeling stuck!
 */
