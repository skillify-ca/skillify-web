//Here's a little coding challenge. You're going to be writing a function that will take in 2 string parameters and output the desired sentence following this template
//Hello my name is (name) and I am learning (subject)!
function greetings(name, subject) {
  //your code goes here
  return;
}

console.log(greetings("Lavan", "CSS")); //output: Hello my name is Lavan and I am learning CSS!
console.log(greetings("Vithushan", "Android Development")); //output: Hello my name is Vithushan and I am learning Android Development!
console.log(greetings("Jacky", "HTML")); //output: Hello my name is Jacky and I am learning HTML!
console.log(greetings("John", "JavaScript")); //output: Hello my name is John and I am learning JavaScript!
