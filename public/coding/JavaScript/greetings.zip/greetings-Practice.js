function greetings(name, subject) {
  //return statement
}

console.log(greetings("Lavan", "CSS")); //output: Hello my name is Lavan and I am learning CSS!
console.log(greetings("Vithushan", "Android Development")); //output: Hello my name is Vithushan and I am learning Android Development!
console.log(greetings("Jacky", "HTML")); //output: Hello my name is Jacky and I am learning HTML!
console.log(greetings("John", "JavaScript")); //output: Hello my name is John and I am learning JavaScript!
